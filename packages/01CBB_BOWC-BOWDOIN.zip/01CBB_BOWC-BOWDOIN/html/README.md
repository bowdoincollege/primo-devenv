# The Primo New UI Customization Workflow Development Environment


##html documentation

 - In this folder you will find static html files in their OTB state
 - You can edit the html to comply with your library requirements
 - Note that you can use Angular Material directives in your html:
 > https://material.angularjs.org/latest/





